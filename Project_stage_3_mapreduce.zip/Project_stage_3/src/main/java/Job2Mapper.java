import java.io.IOException;

import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import static java.lang.Integer.parseInt;

public class Job2Mapper extends Mapper<LongWritable, Text, Text, CompositeKeyStrings> {

    public static enum counter {cnt};
    @Override
    public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
        String[] lineIn = value.toString().split("\t");
        String[] compositeKey = lineIn[0].split(",");

        String state = compositeKey[0];
        String make = compositeKey[1];
        String total = lineIn[1]; // StringUtils.isNumeric(lineIn[1]) ? parseInt(lineIn[1]) : 0;
        context.getCounter(counter.cnt).increment(1);

        context.write(new Text(state), new CompositeKeyStrings(make, total));
    }
}
 
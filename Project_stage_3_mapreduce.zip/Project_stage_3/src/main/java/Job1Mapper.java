import java.io.IOException;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class Job1Mapper extends Mapper<LongWritable, Text, CompositeKeyStrings, IntWritable> {
    @Override
    public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
        String[] lineIn = value.toString().split(",");
        String state = null, zipIn = null, make = null;

        if (lineIn.length > 5) {
            zipIn = lineIn[3].replace("\"", "");
            state = Zip.getStateByZip(zipIn);
            make = lineIn[5].replace("\"", "");
        }

        if( state != null) {
            context.write(new CompositeKeyStrings(state, make), new IntWritable(1));
        }
    }
}

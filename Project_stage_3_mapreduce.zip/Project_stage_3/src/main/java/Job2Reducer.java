import java.io.IOException;
import java.util.Formatter;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import static java.lang.Integer.parseInt;

public class Job2Reducer extends Reducer<Text, CompositeKeyStrings, Text, Text>{

    public void reduce(Text key, Iterable<CompositeKeyStrings> values, Context context) throws IOException, InterruptedException {
        Integer maxTotal = 0;
        String maxMake = "";
        for (CompositeKeyStrings entry : values) {
            Integer total = parseInt(entry.value);
            if (total > maxTotal ){
                maxTotal = total;
                maxMake = entry.key;
            }
        }
        Formatter keyFormat = new Formatter();
        Formatter valueFormat = new Formatter();

        String keyOutput = keyFormat.format("%-15s", key.toString()).toString();
        String output = valueFormat.format("%-12s %-5s", maxMake, maxTotal).toString();

        context.write(new Text(keyOutput), new Text(output));
    }
}
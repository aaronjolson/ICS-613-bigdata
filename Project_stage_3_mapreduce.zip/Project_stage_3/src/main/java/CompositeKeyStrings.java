import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.WritableComparable;

public class CompositeKeyStrings implements WritableComparable<CompositeKeyStrings> {

    String key;
    String value;

    public CompositeKeyStrings() {}

    public CompositeKeyStrings(String key, String value) {
        this.key = key;
        this.value = value;
    }

    public void write(DataOutput dataOutput) throws IOException {
        dataOutput.writeUTF(key);
        dataOutput.writeUTF(value);
    }

    public void readFields(DataInput dataInput) throws IOException {
        key = dataInput.readUTF();
        value = dataInput.readUTF();
    }

    public int compareTo(CompositeKeyStrings other) {
        int ret = key.compareTo(other.key);
        if (ret == 0) {
                return value.compareTo(other.value);
            }
        return ret;
    }

    public String toString() { return key + ", " + value ; }
}
